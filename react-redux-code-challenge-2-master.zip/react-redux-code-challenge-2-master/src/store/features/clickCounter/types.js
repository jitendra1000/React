const INCREMENT_NUMBER = 'challenge/clickCounter/incrementBy1';
const DECREMENT_NUMBER = 'challenge/clickCounter/decrementBy1';
const RESET_TO_ZERO = 'challenge/clickCounter/resetNumberToZero';

export default {
  INCREMENT_NUMBER,
  DECREMENT_NUMBER,
  RESET_TO_ZERO,
};