import React from 'react';

function DetailsPage() {
  return (
    <div>Code for the Details Page goes here</div>
  );
}

export default DetailsPage;